# Phase4-quiz
use below commands to run the code.
npm install
npm start